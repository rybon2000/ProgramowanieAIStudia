using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.Rendering;

namespace UnityEngine.Rendering.Universal.Test
{
    class ConfigurationTest
    {
        [Test]
        public void ValidateConfiguration() { }
    }
}
